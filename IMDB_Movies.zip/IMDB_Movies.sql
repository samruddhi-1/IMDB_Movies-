create database project_movie_database;

use project_movie_database;

CREATE TABLE movies (
    id INT PRIMARY KEY,
    original_title VARCHAR(255),
    budget BIGINT,
    popularity DOUBLE,
    release_date date,
    revenue BIGINT,
    title VARCHAR(255),
    vote_average DOUBLE,
    vote_count INT,
    overview TEXT,
    tagline TEXT,
    uid INT,
    director_id INT
);

INSERT INTO movies (id, original_title, budget, popularity, release_date, revenue, title, vote_average, vote_count, overview, tagline, uid, director_id) VALUES
(43597, 'Avatar', 237000000, 150, '2009-12-10', 2787965087, 'Avatar', 7.2, 11800, 'In the 22nd century, a paraplegic Marine is dispatched to the moon Pandora on a unique mission, but becomes torn between following orders and protecting an alien civilization.', 'Enter the World of Pandora.', 19995, 4762),
(43598, 'Pirates of the Caribbean: At Worlds End', 300000000, 139, '2007-05-19', 961000000, 'Pirates of the Caribbean: At Worlds End', 6.9, 4500, 'Captain Barbossa, long believed to be dead, has come back to life and is headed to the edge of the Earth with Will Turner and Elizabeth Swann. But nothing is quite as it seems.', 'At the end of the world, the adventure begins.', 285, 4763),
(43599, 'Spectre', 245000000, 107, '2015-10-26', 880674609, 'Spectre', 6.3, 4466, 'A cryptic message from Bonds past sends him on a trail to uncover a sinister organization. While M battles political forces to keep the secret service alive, Bond peels back the layers of deceit to reveal the terrible truth behind SPECTRE.', 'A Plan No One Escapes', 206647, 4764),
(43600, 'The Dark Knight Rises', 250000000, 112, '2012-07-16', 1084939099, 'The Dark Knight Rises', 7.6, 9106, 'Following the death of District Attorney Harvey Dent, Batman assumes responsibility for Dents crimes to protect the late attorney"s reputation and is subsequently hunted by the Gotham City Police Department. Eight years later , Batman encounters the mysterious Selina Kyle and the villainous Bane, a new terrorist leader who overwhelms Gotham"s finest. The Dark Knight resurfaces to protect a city that has branded him an enemy.', 'The Legend Ends', 49026, 4765),
(43601, 'John Carter', 260000000, 43, '2012-03-07', 284139100, 'John Carter', 6.1, 2124, 'John Carter is a war-weary, former military captain whos inexplicably transported to the mysterious and exotic planet of Barsoom (Mars) and reluctantly becomes embroiled in an epic conflict. It"s a world on the brink of collapse, and Carter rediscovers his humanity when he realizes the survival of Barsoom and its people rests in his hands."', 'Lost in our world, found in another.', 49529, 4766),
(43602, 'Spider-Man 3', 258000000, 115, '2007-05-01', 890871626, 'Spider-Man 3', 5.9, 3576, 'The seemingly invincible Spider-Man goes up against an all-new crop of villain including the shape-shifting Sandman. While Spider-Mans superpowers are altered by an alien organism, his alter ego, Peter Parker, deals with nemesis Eddie Brock and also gets caught up in a love triangle.', 'The battle within.', 559, 4767),
(43603, 'Tangled', 260000000, 48, '2010-11-24', 591794936, 'Tangled', 7.4, 3330, 'When the kingdoms most wanted-and most charming-bandit Flynn Rider hides out in a mysterious tower, he"s taken hostage by Rapunzel, a beautiful and feisty tower-bound teen with 70 feet of magical, golden hair. Flynn"s curious captor, who"s looking for her ticket out of the tower where she"s been locked away for years, strikes a deal with the handsome thief and the unlikely duo sets off on an action-packed escapade, complete with a super-cop horse, an over-protective chameleon and a gruff gang of pub thugs.""', 'They''re taking adventure to new lengths.', 38757, 4768),
(43604, 'Avengers: Age of Ultron', 280000000, 134, '2015-04-22', 1405403694, 'Avengers: Age of Ultron', 7.3, 6767, 'When Tony Stark tries to jumpstart a dormant peacekeeping program, things go awry and Earths Mightiest Heroes are put to the ultimate test as the fate of the planet hangs in the balance. As the villainous Ultron emerges, it is up to The Avengers to stop him from enacting his terrible plans, and soon uneasy alliances and unexpected action pave the way for an epic and unique global adventure.', 'A New Age Has Come.', 99861, 4769),
(43605, 'Harry Potter and the Half-Blood Prince', 250000000, 98, '2009-07-07', 933959197, 'Harry Potter and the Half-Blood Prince', 7.4, 5293, 'As Harry begins his sixth year at Hogwarts, he discovers an old book marked as ''Property of the Half-Blood Prince'', and begins to learn more about Lord Voldemorts dark past.', 'Dark Secrets Revealed', 767, 4770),
(43607, 'Superman Returns', 270000000, 57, '2006-06-28', 391081192, 'Superman Returns', 5.4, 1400, 'Superman returns to discover his 5-year absence has allowed Lex Luthor to walk free, and that those he was closest too felt abandoned and have moved on. Luthor plots his ultimate revenge that could see millions killed and change the face of the planet forever, as well as ridding himself of the Man of Steel.', NULL, 1452, 4772),
(43608, 'Quantum of Solace', 200000000, 107, '2008-10-30', 586090727, 'Quantum of Solace', 6.1, 2965, 'Quantum of Solace continues the adventures of James Bond after Casino Royale. Betrayed by Vesper, the woman he loved, 007 fights the urge to make his latest mission personal. Pursuing his determination to uncover the truth, Bond and M interrogate Mr. White, who reveals that the organization that blackmailed Vesper is far more complex and dangerous than anyone had imagined.', 'For love, for hate, for justice, for revenge.', 10764, 4773),
(43609, 'Pirates of the Caribbean: Dead Mans Chest', 200000000, 145, '2006-06-20', 1065659812, 'Pirates of the Caribbean: Dead Mans Chest', 7.0, 5246, 'Captain Jack Sparrow works his way out of a blood debt with the ghostly Davey Jones, he also attempts to avoid eternal damnation.', 'Jack is back!', 58, 4763),
(43610, 'The Lone Ranger', 255000000, 49, '2013-07-03', 89289910, 'The Lone Ranger', 5.9, 2311, 'The Texas Rangers chase down a gang of outlaws led by Butch Cavendish, but the gang ambushes the Rangers, seemingly killing them all. One survivor is found, however, by an American Indian named Tonto, who nurses him back to health. The Ranger, donning a mask and riding a white stallion named Silver, teams up with Tonto to bring the unscrupulous gang and others of that ilk to justice.', 'Never Take Off the Mask', 57201, 4763),
(43611, 'Man of Steel', 225000000, 99, '2013-06-12', 662845518, 'Man of Steel', 6.5, 6359, 'A young boy learns that he has extraordinary powers and is not of this earth. As a young man, he journeys to discover where he came from and what he was sent here to do. But the hero in him must emerge if he is to save the world from annihilation and become the symbol of hope for all mankind.', 'You will believe that a man can fly.', 49521, 4771),
(43612, 'The Chronicles of Narnia: Prince Caspian', 225000000, 53, '2008-05-15', 419651413, 'The Chronicles of Narnia: Prince Caspian', 6.3, 1630, 'One year after their incredible adventures in the Lion, the Witch and the Wardrobe, Peter, Edmund, Lucy and Susan Pevensie return to Narnia to aid a young prince whose life has been threatened by the evil King Miraz. Now, with the help of a colorful cast of new characters, including Trufflehunter the badger and Nikabrik the dwarf, the Pevensie clan embarks on an incredible quest to ensure that Narnia is returned to its rightful heir.', 'Hope has a new face.', 2454, 4774),
(43613, 'The Avengers', 220000000, 144, '2012-04-25', 1519557910, 'The Avengers', 7.4, 11776, 'When an unexpected enemy emerges and threatens global safety and security, Nick Fury, director of the international peacekeeping agency known as S.H.I.E.L.D., finds himself in need of a team to pull the world back from the brink of disaster. Spanning the globe, a daring recruitment effort begins!', 'Some assembly required.', 24428, 4769),
(43614, 'Pirates of the Caribbean: On Stranger Tides', 380000000, 135, '2011-05-14', 1045713802, 'Pirates of the Caribbean: On Stranger Tides', 6.4, 4948, 'Captain Jack Sparrow crosses paths with a woman from his past, and hes not sure if it"s love -- or if she"s a ruthless con artist who"s using him to find the fabled Fountain of Youth. When she forces him aboard the Queen Anne"s Revenge, the ship of the formidable pirate Blackbeard, Jack finds himself on an unexpected adventure in which he doesn''t know who to fear more: Blackbeard or the woman from his past.', 'Live Forever Or Die Trying.', 1865, 4775),
(43615, 'Men in Black 3', 225000000, 52, '2012-05-23', 624026776, 'Men in Black 3', 6.2, 4160, 'Agents J (Will Smith) and K (Tommy Lee Jones) are back...in time. J has seen some inexplicable things in his 15 years with the Men in Black, but nothing, not even aliens, perplexes him as much as his wry, reticent partner. But when Ks life and the fate of the planet are put at stake, Agent J will have to travel back in time to put things right. J discovers that there are secrets to the universe that K never told him - secrets that will reveal themselves as he teams up with the young Agent K (Josh Brolin) to save his partner, the agency, and the future of humankind.', 'They are back... in time.', 41154, 4776),
(43616, 'The Hobbit: The Battle of the Five Armies', 250000000, 120, '2014-12-10', 956019788, 'The Hobbit: The Battle of the Five Armies', 7.1, 4760, 'Immediately after the events of The Desolation of Smaug, Bilbo and the dwarves try to defend Erebors mountain of treasure from others who claim it: the men of the ruined Laketown and the elves of Mirkwood. Meanwhile an army of Orcs led by Azog the Defiler is marching on Erebor, fueled by the rise of the dark lord Sauron. Dwarves, elves and men must unite, and the hope for Middle-Earth falls into Bilbo"s hands."', 'Witness the defining chapter of the Middle-Earth saga', 122917, 4777),
(43617, 'The Amazing Spider-Man', 215000000, 89, '2012-06-27', 752215857, 'The Amazing Spider-Man', 6.5, 6586, 'Peter Parker is an outcast high schooler abandoned by his parents as a boy, leaving him to be raised by his Uncle Ben and Aunt May. Like most teenagers, Peter is trying to figure out who he is and how he got to be the person he is today. As Peter discovers a mysterious briefcase that belonged to his father, he begins a quest to understand his parents'' disappearance leading him directly to Oscorp and the lab of Dr. Curt Connors, his fathers former partner. As Spider-Man is set on a collision course with Connors'' alter ego, The Lizard, Peter will make life-altering choices to use his powers and shape his destiny to become a hero.', 'The untold story begins.', 1930, 4778),
(43618, 'Robin Hood', 200000000, 37, '2010-05-12', 310669540, 'Robin Hood', 6.2, 1398, 'When soldier Robin happens upon the dying Robert of Loxley, he promises to return the mans sword to his family in Nottingham. There, he assumes Robert"s identity; romances his widow, Marion; and draws the ire of the town"s sheriff and King John"s henchman, Godfrey."', 'Rise and rise again, until lambs become lions.', 20662, 4779),
(43619, 'The Hobbit: The Desolation of Smaug', 250000000, 94, '2013-12-11', 958400000, 'The Hobbit: The Desolation of Smaug', 7.6, 4524, 'The Dwarves, Bilbo and Gandalf have successfully escaped the Misty Mountains, and Bilbo has gained the One Ring. They all continue their journey to get their gold back from the Dragon, Smaug.', 'Beyond darkness... beyond desolation... lies the greatest danger of all.', 57158, 4777),
(43620, 'The Golden Compass', 180000000, 42, '2007-12-04', 372234864, 'The Golden Compass', 5.8, 1303, 'After overhearing a shocking secret, precocious orphan Lyra Belacqua trades her carefree existence roaming the halls of Jordan College for an otherworldly adventure in the far North, unaware that its part of her destiny.', 'There are worlds beyond our own - the compass will show the way.', 2268, 4780),
(43621, 'King Kong', 207000000, 61, '2005-12-14', 550000000, 'King Kong', 6.6, 2337, 'In 1933 New York, an overly ambitious movie producer coerces his cast and hired ship crew to travel to mysterious Skull Island, where they encounter Kong, a giant ape who is immediately smitten with the leading lady.', 'The eighth wonder of the world.', 254, 4777),
(43622, 'Titanic', 200000000, 100, '1997-11-18', 1845034188, 'Titanic', 7.5, 7562, '84 years later, a 101-year-old woman named Rose DeWitt Bukater tells the story to her granddaughter Lizzy Calvert, Brock Lovett, Lewis Bodine, Bobby Buell and Anatoly Mikailavich on the Keldysh about her life set in April 10th 1912, on a ship called Titanic when young Rose boards the departing ship with the upper-class passengers and her mother, Ruth DeWitt Bukater, and her fiancé, Caledon Hockley. Meanwhile, a drifter and artist named Jack Dawson and his best friend Fabrizio De Rossi win third-class tickets to the ship in a game. And she explains the whole story from departure until the death of Titanic on its first and last voyage April 15th, 1912 at 2:20 in the morning.', 'Nothing on Earth could come between them.', 597, 4762),
(43623, 'Captain America: Civil War', 250000000, 198, '2016-04-27', 1153304495, 'Captain America: Civil War', 7.1, 7241, 'Following the events of Age of Ultron, the collective governments of the world pass an act designed to regulate all superhuman activity. This polarizes opinion amongst the Avengers, causing two factions to side with Iron Man or Captain America, which causes an epic battle between former allies.', 'Divided We Fall', 271110, 4781),
(43624, 'Battleship', 209000000, 64, '2012-04-11', 303025485, 'Battleship', 5.5, 2114, 'When mankind beams a radio signal into space, a reply comes from Planet G, in the form of several alien crafts that splash down in the waters off Hawaii. Lieutenant Alex Hopper is a weapons officer assigned to the USS John Paul Jones, part of an international naval coalition which becomes the worlds last hope for survival as they engage the hostile alien force of unimaginable strength. While taking on the invaders, Hopper must also try to live up to the potential his brother, and his fiancée"s father, Admiral Shane, expect of him."', 'The Battle for Earth Begins at Sea', 44833, 4782),
(43625, 'Jurassic World', 150000000, 418, '2015-06-09', 1513528810, 'Jurassic World', 6.5, 8662, 'Twenty-two years after the events of Jurassic Park, Isla Nublar now features a fully functioning dinosaur theme park, Jurassic World, as originally envisioned by John Hammond.', 'The park is open.', 135397, 4783),
(43626, 'Skyfall', 200000000, 93, '2012-10-25', 1108561013, 'Skyfall', 6.9, 7604, 'When Bonds latest assignment goes gravely wrong and agents around the world are exposed, MI6 is attacked forcing M to relocate the agency. These events cause her authority and position to be challenged by Gareth Mallory, the new Chairman of the Intelligence and Security Committee. With MI6 now compromised from both inside and out, M is left with one ally she can trust: Bond. 007 takes to the shadows - aided only by field agent, Eve - following a trail to the mysterious Silva, whose lethal and hidden motives have yet to reveal themselves.""', 'Think on your sins.', 37724, 4764),
(43627, 'Spider-Man 2', 200000000, 35, '2004-06-25', 783766341, 'Spider-Man 2', 6.7, 4321, 'Peter Parker is going through a major identity crisis. Burned out from being Spider-Man, he decides to shelve his superhero alter ego, which leaves the city suffering in the wake of carnage left by the evil Doc Ock. In the meantime, Parker still can''t act on his feelings for Mary Jane Watson, a girl hes loved since childhood.', 'Theres a hero in all of us.', 558, 4767),
(43628, 'Iron Man 3', 200000000, 77, '2013-04-18', 1215439994, 'Iron Man 3', 6.8, 8806, 'When Tony Starks world is torn apart by a formidable terrorist called the Mandarin, he starts an odyssey of rebuilding and retribution.""', 'Unleash the power behind the armor.', 68721, 4784),
(43629, 'Alice in Wonderland', 200000000, 78, '2010-03-03', 1025491110, 'Alice in Wonderland', 6.4, 4645, 'Alice, an unpretentious and individual 19-year-old, is betrothed to a dunce of an English nobleman. At her engagement party, she escapes the crowd to consider whether to go through with the marriage and falls down a hole in the garden after spotting an unusual rabbit. Arriving in a strange and surreal place called ''Underland,'' she finds herself in a world that resembles the nightmares she had as a child, filled with talking animals, villainous queens and knights, and frumious bandersnatches. Alice realizes that she is there for a reason to conquer the horrific Jabberwocky and restore the rightful queen to her throne.', 'You''re invited to a very important date.', 12155, 4785),
(43630, 'X-Men: The Last Stand', 210000000, 3, '2006-05-24', 459359555, 'X-Men: The Last Stand', 6.3, 3525, 'When a cure is found to treat mutations, lines are drawn amongst the X-Men and The Brotherhood, a band of powerful mutants organized under Xaviers former ally, Magneto.', 'Take a Stand', 36668, 4786),
(43631, 'Monsters University', 200000000, 89, '2013-06-20', 743559607, 'Monsters University', 7.0, 3528, 'A look at the relationship between Mike and Sulley during their days at Monsters University when they weren''t necessarily the best of friends.', 'School never looked this scary.', 62211, 4787),
(43632, 'Transformers: Revenge of the Fallen', 150000000, 21, '2009-06-19', 836297228, 'Transformers: Revenge of the Fallen', 6.0, 3138, 'Sam Witwicky leaves the Autobots behind for a normal life. But when his mind is filled with cryptic symbols, the Decepticons target him and he is dragged back into the Transformers'' war.', 'Revenge is coming.', 8373, 4788),
(43633, 'Transformers: Age of Extinction', 210000000, 116, '2014-06-25', 1091405097, 'Transformers: Age of Extinction', 5.8, 3095, 'As humanity picks up the pieces, following the conclusion of Transformers: Dark of the Moon, Autobots and Decepticons have all but vanished from the face of the planet. However, a group of powerful, ingenious businessman and scientists attempt to learn from past Transformer incursions and push the boundaries of technology beyond what they can control - all while an ancient, powerful Transformer menace sets Earth in his cross-hairs.', 'This is not war. Its extinction.', 91314, 4788),
(43634, 'Oz: The Great and Powerful', 200000000, 46, '2013-03-07', 491868548, 'Oz: The Great and Powerful', 5.7, 3530, 'Oscar Diggs, a small-time circus illusionist and con-artist, is whisked from Kansas to the Land of Oz where the inhabitants assume hes the great wizard of prophecy, there to save Oz from the clutches of evil.', 'In Oz, nothing is what it seems', 68728, 4767),
(43636, 'TRON: Legacy', 170000000, 73, '2010-12-10', 400062763, 'TRON: Legacy', 6.3, 2841, 'Sam Flynn, the tech-savvy and daring son of Kevin Flynn, investigates his fathers disappearance and is pulled into The Grid. With the help of a mysterious program named Quorra, Sam quests to stop evil dictator Clu from crossing into the real world.', 'The Game Has Changed.', 20526, 4789),
(43637, 'Cars 2', 200000000, 49, '2011-06-11', 559852396, 'Cars 2', 5.8, 2033, 'Star race car Lightning McQueen and his pal Mater head overseas to compete in the World Grand Prix race. But the road to the championship becomes rocky as Mater gets caught up in an intriguing adventure of his own: international espionage.', 'Ka-ciao!', 49013, 4790),
(43638, 'Green Lantern', 200000000, 51, '2011-06-16', 219851172, 'Green Lantern', 5.1, 2487, 'For centuries, a small but powerful force of warriors called the Green Lantern Corps has sworn to keep intergalactic order. Each Green Lantern wears a ring that grants him superpowers. But when a new enemy called Parallax threatens to destroy the balance of power in the Universe, their fate and the fate of Earth lie in the hands of the first human ever recruited.', 'In our darkest hour, there will be light.', 44912, 4791),
(43639, 'Toy Story 3', 200000000, 59, '2010-06-16', 1066969703, 'Toy Story 3', 7.6, 4597, 'Woody, Buzz, and the rest of Andys toys haven''t been played with in years. With Andy about to go to college, the gang find themselves accidentally left at a nefarious day care center. The toys must band together to escape and return home to Andy.', 'No toy gets left behind.', 10193, 4792),
(43640, 'Terminator Salvation', 200000000, 71, '2009-05-20', 371353001, 'Terminator Salvation', 5.9, 2463, 'All grown up in post-apocalyptic 2018, John Connor must lead the resistance of humans against the increasingly dominating militaristic robots. But when Marcus Wright appears, his existence confuses the mission as Connor tries to determine whether Wright has come from the future or the past -- and whether hes friend or foe.', 'The End Begins.', 534, 4793),
(43641, 'Furious 7', 190000000, 102, '2015-04-01', 1506249360, 'Furious 7', 7.3, 4176, 'Deckard Shaw seeks revenge against Dominic Toretto and his family for his comatose brother.', 'Vengeance Hits Home', 168259, 4794),
(43642, 'World War Z', 200000000, 81, '2013-06-20', 531865000, 'World War Z', 6.7, 5560, 'Life for former United Nations investigator Gerry Lane and his family seems content. Suddenly, the world is plagued by a mysterious infection turning whole human populations into rampaging mindless zombies. After barely escaping the chaos, Lane is persuaded to go on a mission to investigate this disease. What follows is a perilous trek around the world where Lane must brave horrific dangers and long odds to find answers before human civilization falls.', 'Remember Philly!', 72190, 4773),
(43644, 'Star Trek Into Darkness', 190000000, 78, '2013-05-05', 467365246, 'Star Trek Into Darkness', 7.4, 4418, 'When the crew of the Enterprise is called back home, they find an unstoppable force of terror from within their own organization has detonated the fleet and everything it stands for, leaving our world in a state of crisis. With a personal score to settle, Captain Kirk leads a manhunt to a war-zone world to capture a one man weapon of mass destruction. As our heroes are propelled into an epic chess game of life and death, love will be challenged, friendships will be torn apart, and sacrifices must be made for the only family Kirk has left: his crew.', 'Earth Will Fall', 54138, 4795),
(43646, 'The Great Gatsby', 105000000, 61, '2013-05-10', 351040419, 'The Great Gatsby', 7.3, 3769, 'An adaptation of F. Scott Fitzgeralds Long Island-set novel, where Midwesterner Nick Carraway is lured into the lavish world of his neighbor, Jay Gatsby. Soon enough, however, Carraway will see through the cracks of Gatsby"s nouveau riche existence, where obsession, madness, and tragedy await."', 'Reserving judgments is a matter of infinite hope... I come to the admission that it has a limit.', 64682, 4796),
(43647, 'Prince of Persia: The Sands of Time', 150000000, 62, '2010-05-19', 335154643, 'Prince of Persia: The Sands of Time', 6.2, 2317, 'A rogue prince reluctantly joins forces with a mysterious princess and together, they race against dark forces to safeguard an ancient dagger capable of releasing the Sands of Time gift from the gods that can reverse time and allow its possessor to rule the world.', 'Defy the Future', 9543, 4797);

select * 
from movies;

select count(*)
from movies;

select *
from directors;

alter table movies
drop primary key;

alter table movies
drop column id;

ALTER TABLE movies
RENAME COLUMN director_id TO id;

SHOW KEYS FROM directors 
WHERE Key_name = 'PRIMARY';

ALTER TABLE directors
ADD PRIMARY KEY (id);

-- ------------------------------------------------------------------------------------------------------------------------------------
-- a)Can you get all data about movies? 
select * 
from movies;

-- b)How do you get all data about directors?
select *
from directors;

-- c)Check how many movies are present in IMDB.
select count(*) as TotalMovies
from movies;

-- d)Find these 3 directors: James Cameron ; Luc Besson ; John Woo
select * 
from directors
where name in('James Cameron','Luc Besson','John Woo');

-- e)Find all directors with name starting with S.
select *
from directors
where name like 'S%';

-- f)Count female directors. (0/2 = Male , 1 = Female)
select count(*)  as female_director
from directors
where gender = 1;

-- g)Find the name of the 10th first women directors?
select * 
from directors
where gender = 1
order by id
limit 1 offset 9;

-- h)What are the 3 most popular movies?
select * 
from movies
order by popularity desc
limit 3;

-- i)What are the 3 most bankable movies?
select * 
from movies
order by revenue desc
limit 3;

-- j)What is the most awarded average vote since the January 1st, 2000?
select  max(vote_average) 
as Most_awarded_AVGVote
from movies
WHERE release_date >= '2000-01-01';

SELECT title, vote_average
FROM movies
WHERE release_date >= '2000-01-01'
ORDER BY vote_average DESC
LIMIT 1;

-- k)Which movie(s) were directed by Brenda Chapman?
select * from movies;
select * from directors;

SELECT m.original_title, d.name
FROM movies m
INNER JOIN directors d
ON m.id = d.id
WHERE d.name = 'Brenda Chapman';

-- l)Which director made the most movies?
SELECT d.name, COUNT(m.id) AS Total_Movies
FROM directors d
INNER JOIN movies m
ON d.id = m.id
GROUP BY d.id, d.name
ORDER BY Total_Movies DESC
LIMIT 1;

-- m)Which director is the most bankable?
SELECT d.name, sum(m.revenue) AS Max_Revenue
FROM directors d
INNER JOIN movies m
ON d.id = m.id
GROUP BY d.id, d.name
ORDER BY Max_Revenue DESC
LIMIT 1;
